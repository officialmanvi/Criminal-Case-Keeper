from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from ttkthemes import ThemedTk
from PIL import Image, ImageTk
import CriminalRegistration,Selection,Database,VisitorTree
import matplotlib.pyplot as MPL 
import numpy as NP
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
# from matplotlib.figure import Figure



class dashboard:
    def __init__(self,data):
        # self.title = title
        #defining window
        self.window =ThemedTk()

        #getting Display Co-ordinates
        self.xcorr = self.window.winfo_screenwidth()
        self.ycorr = self.window.winfo_screenheight()

        #declaring width and height of window
        self.width = 1200
        self.height = 700

        #getting margins of window in order to place window in the mid of display
        self.xcorr = int((self.xcorr)/2 - (self.width)/2)
        self.ycorr = int((self.ycorr)/2 - (self.height)/2)

        #setting margins and dimensions of window
        self.window.geometry(f"{self.width}x{self.height}+{self.xcorr}+{int(self.ycorr/1.5)}")

        #setting title of Login page
        self.window.title(f"Dashboard")
        def visitor():
            self.window.destroy()
            Selection.Selection(1,data)
            
        def criminal():
            self.window.destroy()
            Selection.Selection(2,data)
            
        def CriminalReg():
            self.window.destroy()
            CriminalRegistration.Register(data)

        def visitorTree():
            self.window.destroy()
            visitorTree.Selection(data)


        #applying style:
        style = ttk.Style(self.window)
        style.theme_use('arc')

        #placing frame
        self.backFrame = Frame(self.window,bg="#ffffff",height=self.height,width=self.width)
        self.backFrame.place(x=0,y=0)

        #creating menubar
        # self.menubar = Menu(self.window,relief=FLAT)
        # self.menubar.add_command(label = "View Criminal",command=criminal)
        # self.menubar.add_command(label = "Add visitor",command=visitor)
        # self.menubar.add_command(label = "Register Criminal",command=CriminalReg)
       
        #placing frame
        self.Frame = Frame(self.backFrame,height=700,width=400,bg = "#932df8")
        self.Frame.place(x=0,y=0)
        
        frameImg7= Image.open("images/user.png")
        frameImg7 = frameImg7.resize((100,100))
        frameImg7 = ImageTk.PhotoImage(frameImg7)
        ttk.Label(self.Frame,image= frameImg7,background = "#932df8",relief=FLAT).place(x=150,y=30)
        
        ttk.Label(self.Frame,text = data[0], background="#932df8",foreground="#ffffff",font=("MuseoModerno",25) ).place(anchor="center",x=200,y=160)
        
        
        # frameImg= Image.open("images/Dash.png")
        # # frameImg = frameImg.resize((230,100))
        # frameImg = ImageTk.PhotoImage(frameImg)
        # Button(self.Frame,image= frameImg,background = "#932df8",relief=FLAT).place(x=45,y=250)
        
        frameImg1= Image.open("images/view.png")
        # frameImg = frameImg.resize((230,100))
        frameImg1 = ImageTk.PhotoImage(frameImg1)
        Button(self.Frame,image= frameImg1,command=criminal,bg = "#932df8",relief=FLAT).place(x=45,y=320)
        
        frameImg2= Image.open("images/add.png")
        # frameImg = frameImg.resize((230,100))
        frameImg2 = ImageTk.PhotoImage(frameImg2)
        Button(self.Frame,image= frameImg2,command=CriminalReg,bg = "#932df8",relief=FLAT).place(x=45,y=390)
        
        frameImg3= Image.open("images/AddVisitor.png")
        # frameImg = frameImg.resize((230,100))
        frameImg3 = ImageTk.PhotoImage(frameImg3)
        Button(self.Frame,image= frameImg3,command= visitor,bg = "#932df8",relief=FLAT).place(x=45,y=460)
        
        frameImg4= Image.open("images/view_visitor.png")
        # frameImg = frameImg.resize((230,100))
        frameImg4 = ImageTk.PhotoImage(frameImg4)
        Button(self.Frame,image= frameImg4,bg = "#932df8",relief=FLAT).place(x=45,y=530)
        
        
        
        # Right Frame
        self.rightframe=Frame(self.backFrame,bg="#ffffff",width=800,height=700)
        self.rightframe.place(x=400,y=0)
        
        
        CriminalCount = Database.getCriminalCount()
        CivilianCount = Database.getCivilianCount()

        ttk.Label(self.rightframe,text="Number of Prisoner",font=("Museomoderno",20),background="#ffffff").place(x=50,y=30)
        fig,ax = MPL.subplots()
        # fig = fig.set_figwidth(4)

        Canvas = FigureCanvasTkAgg(fig,master=self.rightframe)
        # Canvas.set
        # Canvas.get_tk_widget().pack(side="right",padx=80,pady=50,fill=BOTH,expand=1)
        Canvas.get_tk_widget().place(x=-60,y=70)
        y = NP.array([CriminalCount[0],CivilianCount[0]])
        mylabels = ["criminal","civilian"]
        myexplore = [0.2,0.0]
        ax.pie(y,labels=mylabels,explode=myexplore,shadow=True,colors=['#932df8','#3d72f9'],startangle=0,radius=1)
        ax.legend(title="Number of Criminals")
        Canvas.draw()


        ttk.Label(self.rightframe,text=f"Total Prisoner : {CivilianCount[0]+CriminalCount[0]}",font=("Calibri",15,'bold'),background="#ffffff").place(x=550,y=150)
        ttk.Label(self.rightframe,text=f"Criminals: {CriminalCount[0]}",font=("Calibri",15,'bold'),background="#ffffff").place(x=550,y=205)
        ttk.Label(self.rightframe,text=f"Civil : {CivilianCount[0]}",font=("Calibri",15,'bold'),background="#ffffff").place(x=550,y=180)
        

        ttk.Label(self.rightframe,text=f"Visitor Count: {Database.getVisitorCount()[0]}",background="#ffffff",font=("Calibri",20)).place(x=50,y=560)
        #placing window in loop
        self.window.mainloop()

if __name__=="__main__":
    dashboard(('Himanshu',))
