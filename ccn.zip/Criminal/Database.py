import mysql.connector

# Creating connection with database
conn = mysql.connector.connect(host="localhost",user="root",passwd="Secureit4321@",database="criminalRecords")

executor = conn.cursor()
def loginFunction(data):
    try:
        executor.execute('SELECT * FROM `login` where `Username`= %s and `Password`= %s',data)
        return executor.fetchone()
    except Exception as e:
        print(e)
        
        
def addVisitor(data):
    try:
        executor.execute("insert into visitordetail(`visitorName`,`VisitorID`,`idNumber`,`criminalID`,`date`,`visitorsRelation`,`contactNo`)values(%s,%s,%s,%s,%s,%s,%s)",data)
        conn.commit()
        return True
    except Exception as e:
        print(e)
        return False
    
    
#Getting count of criminal data
def getcount():
    try:
        executor.execute("select count(*)from criminaldetails") 
        return executor.fetchone()
    except Exception as e:
        print(e)
        
        
def insertCriminal(data):
    try:
        executor.execute("insert into criminaldetails(`jailID`,`criminalName`,`address`,`gender`,`DOB`,`idType`,`idNumber`,`image`,`offenceType`,`dateofIncident`,`jailTerm`,`crimeSummary`)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",data)
        conn.commit()
        return True
    except Exception as e:
        print(e)
        return False
                
# def inserting

def selectCriminal():
    try:
        executor.execute("select jailId,criminalName,gender,offenceType from criminaldetails")
        return executor.fetchall()
    except Exception as e:
        print(e)
        

def fetchCriminalBasedOnName(data):
    try:
        executor.execute(f"select jailId,criminalName,gender,offenceType from criminaldetails where `criminalName` like '%{data}%'")
        return executor.fetchall()
    except Exception as e:
        print(e)
        
                   
def fetchCriminalBasedOnjailID(data):
    try:
        executor.execute(f"select jailId,criminalName,gender,offenceType from criminaldetails where `jailID` like '%{str(data)}%'")
        return executor.fetchall()
    except Exception as e:
        print(e)
   
        
def fetchVisitor():
    try:
        executor.execute("Select visitordetail.date, visitordetail.ID,visitordetail.visitorName, criminaldetails.criminalName, visitordetail.visitorsRelation from visitordetail inner join criminaldetails on visitordetail.criminalID = criminaldetails.jailID") 
        return executor.fetchall()
    except Exception as e:
        print(e)
        
        
# def fetchVisitorBasedOnCriminalId(data):
#     try:
#         executor.execute(f"Select visitordetail.date, visitordetail.ID,visitordetail.visitorName, criminaldetails.criminalName, visitordetail.visitorsRelation from visitordetail inner join criminaldetails on criminaldetails.jailID like '%{data}%' and visitordetail.criminalID like '%{data}%' and criminaldetails.jailID = visitordetail.criminalID") 
#         return executor.fetchall()
#     except Exception as e:
#         print(e)
        
# print(fetchVisitorBasedOnCriminalId(' CCK1'))


def fetchCriminal(data):
    try:
        executor.execute(f"select * from criminaldetails where jailID = '{data}'")
        return executor.fetchone()
    except Exception as e:
        print(e)
    
# print(fetchCriminal('CCK6'))


def fetchVisitorForCriminal(data):
    try:
        executor.execute(f"Select date,visitorName,visitorID,idNumber,visitorsRelation,contactNo from visitordetail where criminalID = '{data}'")
        return executor.fetchall()
    except Exception as e:
        print(e)
        
        
def getCriminalCount():
    try:
        executor.execute("select count(*) from criminaldetails where offenceType='criminal'")
        return executor.fetchone()
    except Exception as e:
        print(e)
        
def getCivilianCount():
    try:
        executor.execute("select count(*) from criminaldetails where offenceType='civilian'")
        return executor.fetchone()
    except Exception as e:
        print(e)
        
def getTotalCount():
    try:
        executor.execute("select count(*) from criminaldetails")
        return executor.fetchone()
    except Exception as e:
        print(e)
        
def getVisitorCount():
    try:
        executor.execute("select count(*) from visitordetail")
        return executor.fetchone()
    except Exception as e:
        print(e)
print(getVisitorCount())





        


