from tkinter import *
from tkinter import ttk
from ttkthemes import ThemedTk
from PIL import Image,ImageTk
import threading,os,time
import login


class welcomePage :
    
    def __init__(self):
        self.window = ThemedTk()

        #setting theme
        style = ttk.Style(self.window)
        style.theme_use('arc')
    
        #setting title
        self.window.title("Welcome Screen")

        #getting display co-ordinates 
        self.xCorr = self.window.winfo_screenwidth()
        self.yCorr = self.window.winfo_screenheight()

       
        #window width and height
        self.width = 600
        self.height = 300
        
        #getting margins data 
        self.xMargin = int((self.xCorr/2)-(self.width/2))
        self.yMargin = int((self.yCorr/2)-(self.height/2))

        #setting size of window
        self.window.geometry(f"{self.width}x{self.height}+{self.xMargin}+{self.yMargin}")

        #setting window resizable property to false
        self.window.resizable(False,False)

        #setting frame for welcome window
        self.welcomeFrame = Frame(self.window,bg="#ffffff",height=self.height,width=self.width)
        self.welcomeFrame.place(x=0,y=0)

        #placing and configuring title 
        styleHeading = ttk.Style()
        styleHeading.configure("TLabel",background="#ffffff",foreground="#000000")
        self.titleLabel = ttk.Label(self.welcomeFrame,text="Criminal Case Keeper",style="TLabel",font=('MuseoModerno',35))
        self.titleLabel.place(x=60,y=130)

           #placing Software Description
        self.description = ttk.Label(self.welcomeFrame,text="The Criminal Case Keeper project emerges as a game-changer.",style="TLabel",font=('MuseoModerno',12))
        self.description.place(x=70,y=190)

        #placing Images
        
        img = Image.open("images/justice statue.jpg")
        img = img.resize((150,150))
        photo = ImageTk.PhotoImage(img)
        label = Label(self.welcomeFrame,image=photo,borderwidth=0,bg="#ffffff",height=150,width=150)
        label.place(x=230,y=0)
        

        #setting progressbar
        self.progressBar = ttk.Progressbar(self.welcomeFrame,orient="horizontal",mode="determinate",maximum=100,length=440)
        self.progressBar.place(x=80,y=240)

        #function that controls the progressbar values
        def startProg():
            self.progressBar['value']=0.0
            while True:
                self.progressBar['value']+=1
                #print(self.progressBar['value'])
                if(self.progressBar['value']==99.0):
                    self.window.withdraw()
                    os.system("python login.py")
                    self.window.destroy()
                else:
                    time.sleep(.05)
                    continue
                    
        #initializing thread
        threading.Thread(target=startProg).start()
            
       
        #setting loop
        self.window.mainloop()

if __name__=="__main__":
    welcomePage()

