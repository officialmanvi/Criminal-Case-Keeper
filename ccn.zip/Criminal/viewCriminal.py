from tkinter import *
from tkinter import ttk
from ttkthemes import ThemedTk
from PIL import Image, ImageTk
from tkinter import filedialog 
import Database,Selection
import base64

class View:
    def __init__(self,key,data):
        
        self.key = key
        
        
        self.data=Database.fetchCriminal(self.key)
         #defining window
        self.window =ThemedTk()

        #getting Display Co-ordinates
        self.xcorr = self.window.winfo_screenwidth()
        self.ycorr = self.window.winfo_screenheight()

        #declaring width and height of window
        self.width = 1200   
        self.height = 700

        #getting margins of window in order to place window in the mid of display
        self.xcorr = int((self.xcorr)/2 - (self.width)/2)
        self.ycorr = int((self.ycorr)/2 - (self.height)/2)

        #setting margins and dimensions of window
        self.window.geometry(f"{self.width}x{self.height}+{self.xcorr}+{int(self.ycorr/1.5)}")
        self.window.resizable(False,False)
        
         #setting title of Login page
        self.window.title("display criminal")

        #applying style:
        style = ttk.Style(self.window)
        style.theme_use('adapta')
        
         #placing frame
        self.backFrame = Frame(self.window,bg="#ffffff",height=self.height,width=self.width)
        self.backFrame.place(x=0,y=0)

        #placing title Label
        self.titleName = Label(self.backFrame,text=self.data[2],bg="#ffffff",font=("museoModerno",25))
        self.titleName.place(x=50,y=37)
        
        #Displaying Image 
        decoded = open('criminalrecord.jpg','wb')
        decoded.write(base64.b64decode((self.data[-1])))
        decoded.close()
        
        img = Image.open('criminalrecord.jpg')
        img = img.resize((200,300))
        img = ImageTk.PhotoImage(img)
        ttk.Label(self.backFrame,image= img).place(x=900, y=100)
        
        ttk.Style().configure("Custom.TLabel",background = "#ffffff",font = ("libre baskerville",13))
        self.DOBlbl = ttk.Label(self.backFrame,text = f"Date Of Birth: {self.data[5]}",style="Custom.TLabel").place(x=145, y=100)
        ttk.Label(self.backFrame,text = f"Gender: {self.data[4]}",style="Custom.TLabel").place(x=400, y=100)
        ttk.Label(self.backFrame,text = f"Address: {self.data[3]}",style="Custom.TLabel").place(x=145, y=135)
        ttk.Label(self.backFrame,text = f"JailID: {self.data[1]}",style="Custom.TLabel").place(x=600, y=100)
        ttk.Label(self.backFrame,text = f"GovID: {self.data[6]}",style="Custom.TLabel").place(x=145, y=170)
        ttk.Label(self.backFrame,text = f"GovID No: {self.data[7]}",style="Custom.TLabel").place(x=350, y=170)
        ttk.Label(self.backFrame,text = f"Type of Offence: {self.data[8]}",style="Custom.TLabel").place(x=145, y=205)
        ttk.Label(self.backFrame,text = f"Sentence Period: {self.data[-3]} years",style="Custom.TLabel").place(x=450, y=205)
        
        
        self.CrimeSummery = ttk.Label(self.backFrame,text="Criminal Description", style="Custom.TLabel",font=("libre baskerville",14,"bold")).place(x=100, y=240)
        
        #placing frame
        self.Frame = Frame(self.backFrame,height=135,width=655)
        self.Frame.place(x=145,y=270)
        
        frameImg= Image.open("images/frame.png")
        frameImg = frameImg.resize((650,130))
        frameImg = ImageTk.PhotoImage(frameImg)
        ttk.Label(self.Frame,image= frameImg,background = "#ffffff",relief=FLAT).place(x=0,y=0)
        
        ttk.Label(self.Frame,text=self.data[-2],style= "Custom.TLabel").place(x=5,y=5)
        
        
        def conversion(abc):
            count = 0
            a = []
            for i in abc:
                b = []
                count += 1
                b.append(count)
                b.append(i[0].split(" "))
                b.append(i[1])
                b.append(i[2])
                b.append(i[3])
                b.append(i[4])
                b.append(i[5])
                a.append(tuple(b))
            return a
        
        def fetch():
            data = Database.fetchVisitorForCriminal(self.key)
            res = conversion(data)
            return res
      
        self.treeFrame = Frame(self.backFrame,background = "#d9d9d9",width= 1100,height = 225)
        self.treeFrame.place(x=50,y=450)
        ttk.Label(self.backFrame,text="Visitor Details",style= "Custom.TLabel",font=("libre baskerville",14,"bold")).place(x=100,y=415)
        
        
        
        
        cols = ['S.No','Date','VisitorName','VisitorID','IDNo','VisitorRelation','Contact']
        colswidth={'S.No':100,'VisitorName':250,'VisitorID':125,'IDNo':150,'Date':150,'VisitorRelation':150,'Contact':100}
        colsTitle = {'S.No':"S. No.",'VisitorName':"VisitorName",'VisitorID':"VisitorID",'IDNo':"IDNo",'Date':"Date",'VisitorRelation':"VisitorRelation",'Contact':"Contact"}

        self.tree = ttk.Treeview(self.treeFrame,columns=cols,show="headings")
        ttk.Style().configure("Treeview",rowheight=15,font=("Libre Baskerville",9))
        ttk.Style().configure("Treeview.Heading",foreground="#932df8",font=("Libre Baskerville",13,"bold"))



        for i in cols:
            self.tree.column(f"{i}",width=colswidth[i],anchor=CENTER,)
            self.tree.heading(f"{i}",text=colsTitle[i])
            
        getting = fetch()
        for i in getting:
            self.tree.insert('',END,text = i[1],values = i)
           
        self.tree.pack(side=LEFT)
        Scroll = ttk.Scrollbar(self.treeFrame,orient="vertical",command=self.tree.yview)
        self.tree.configure(yscrollcommand=Scroll.set)
        Scroll.pack(side=RIGHT,fill=Y)


        #binding close 
        def onClosing():
            self.window.destroy()
            Selection.Selection(2,data)
           
        self.window.protocol("WM_DELETE_WINDOW",onClosing)
      
        
        self.window.mainloop()
if __name__ == "__main__":
    View("CCK4",('himanshu',))
        
        

