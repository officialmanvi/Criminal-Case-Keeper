from tkinter import *
from tkinter import ttk
from ttkthemes import ThemedTk
from PIL import Image,ImageTk
from tkinter import messagebox
import Database,VisitorRegistration,Dashboard


class Selection:
  def actions(self,e):
      # print(e)
    tt = self.tree.item(self.tree.focus())
    self.window.destroy()
    print(tt.get('text'))
    VisitorRegistration.visitor(tt.get('text'))
  def __init__(self,data):
        
    self.data=[]
         #defining window
    self.window =ThemedTk()

        #getting Display Co-ordinates
    self.xcorr = self.window.winfo_screenwidth()
    self.ycorr = self.window.winfo_screenheight()

        #declaring width and height of window
    self.width = 1200   
    self.height = 700

        #getting margins of window in order to place window in the mid of display
    self.xcorr = int((self.xcorr)/2 - (self.width)/2)
    self.ycorr = int((self.ycorr)/2 - (self.height)/2)

        #setting margins and dimensions of window
    self.window.geometry(f"{self.width}x{self.height}+{self.xcorr}+{int(self.ycorr/1.5)}")
    self.window.resizable(False,False)
        
         #setting title of Login page
    self.window.title("SELECT VISTOR")

        #applying style:
    style = ttk.Style(self.window)
    style.theme_use('adapta')
        
          #placing frame
    self.backFrame = Frame(self.window,bg="#ffffff",height=self.height,width=self.width)
    self.backFrame.place(x=0,y=0)

        #placing title Label
    configLabel = ttk.Style()
    configLabel.configure("TLabel",background="#ffffff",foreground="#932df8",font=("museoModerno",25))
    self.titleName = Label(self.backFrame,text="Select",bg="#ffffff",font=("museoModerno",25))
    self.titleName.place(x=50,y=37)
    self.titleName1 = ttk.Label(self.backFrame,text="Visitor",style="TLabel")
    self.titleName1.place(x=150,y=37)

    ttk.Style().configure("Custom.TEntry")
    self.searchEntry = ttk.Entry(self.backFrame,width=90,font=("Libre Baskerville",13),style="Custom.TEntry")
    self.searchEntry.place(x=125,y=108)

    photo= ImageTk.PhotoImage(Image.open("images/search2.png"))


    
    
    #method for deleting records from a tree view
    def removeAll():
      for i in self.tree.get_children():
        self.tree.delete(i)
        
          
    def conversion(abc):
      count = 0
      a = []
      for i in abc:
        b = []
        count += 1
        b.append(count)
        b.append(i[0])
        b.append(i[1])
        b.append(i[2])
        b.append(i[3])
        b.append(i[4])
        a.append(tuple(b))
      return a
    
    #methods for search button
    def submitSearch():
      string=self.searchEntry.get()
      if string.isalpha():
        print("isalpha")
        res=Database.fetchCriminalBasedOnName(string)
        data=conversion(res)
        removeAll()
        for i in data:
          self.tree.insert('',END,text=i[1],values=i)
                
      elif string.isalnum():
        print("isalnum")
        res=Database.fetchCriminalBasedOnjailID(string)
        data = conversion(res)   
        removeAll()
        for i in data:
            self.tree.insert('',END,text=i[1],values=i)
    
    def fetch():
      data = Database.fetchVisitor()
      res = conversion(data)
      return res
      
    
    # ttk.Style().configure("TButton",font=("museoModerno",10,"bold"),highlightthickness="#932df8")
    self.searchBTN = ttk.Button(self.backFrame,width=10,image=photo,text="Search",command = submitSearch)
    self.searchBTN.place(x=988,y=106)
    
   
    self.treeFrame = Frame(self.backFrame,width=1100,height=300,bg="#ffeefa")
    self.treeFrame.place(x=50,y=200)
        
    cols = ['S.No','Date','VisitorID','VisitorName','CriminalName','VisitorRelation']
    colswidth={'S.No':160,'Date':160,'VisitorID': 120,'VisitorName':280,'CriminalName':160,'VisitorRelation':160}
    colsTitle = {'S.No':"S. No.",'Date':"Date",'VisitorID':"VisitorID",'VisitorName':"Visitor Name",'CriminalName':"Criminal Name",'VisitorRelation':"Visitor Relation"}

    self.tree = ttk.Treeview(self.treeFrame,columns=cols,show="headings")
    ttk.Style().configure("Treeview",rowheight=34)
    ttk.Style().configure("Treeview.Heading",foreground="#932df8",font=("Libre Baskerville",13,"bold"))

    for i in cols:
      self.tree.column(f"{i}",width=colswidth[i],anchor=CENTER,)
      self.tree.heading(f"{i}",text=colsTitle[i])
      
    getting = fetch()
    for i in getting:
      self.tree.insert('',END,text = i[1],values = i)
        
    self.tree.bind('<Double-Button-1>',self.actions)

    self.tree.pack(side=LEFT)
    Scroll = ttk.Scrollbar(self.treeFrame,orient="vertical",command=self.tree.yview)
    self.tree.configure(yscrollcommand=Scroll.set)
    Scroll.pack(side=RIGHT,fill=Y)

        
    def onClosing():
            self.window.destroy()
            Dashboard.dashboard(data)
    self.window.protocol("WM_DELETE_WINDOW",onClosing)
        
    self.window.mainloop()
if __name__ == "__main__":
  Selection()
