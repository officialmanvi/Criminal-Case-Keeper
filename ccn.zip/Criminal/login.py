from tkinter import *
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter import messagebox
from PIL import Image,ImageTk
import threading,time,Database
import Dashboard

class login :
    def __init__(self):

        #defining window
        self.window =ThemedTk()

        #getting Display Co-ordinates
        self.xcorr = self.window.winfo_screenwidth()
        self.ycorr = self.window.winfo_screenheight()
        self.window.resizable(False,False)
        #declaring width and height of window
        self.width = 1200
        self.height = 700

        #getting margins of window in order to place window in the mid of display
        self.xcorr = int((self.xcorr)/2 - (self.width)/2)
        self.ycorr = int((self.ycorr)/2 - (self.height)/2)

        #setting margins and dimensions of window
        self.window.geometry(f"{self.width}x{self.height}+{self.xcorr}+{self.ycorr}")

        #setting title of register page
        self.window.title("Login User")

        #applying style:
        style = ttk.Style(self.window)
        style.theme_use('arc')

        #placing frame
        self.backFrame = Frame(self.window,bg="White",height=self.height,width=self.width)
        self.backFrame.place(x=0,y=0)

        #placing title Label
        configLabel = ttk.Style()
        configLabel.configure("TLabel",background="White",foreground="#000000",font=("MuseoModerno",25,))
        self.FirstName = ttk.Label(self.backFrame,text="Criminal ",style="TLabel")
        self.FirstName.place(x=50,y=35)
        
        self.backName = ttk.Label(self.backFrame,text="Case Keeper",foreground="#932df8",style="TLabel")
        self.backName.place(x=185,y=35)

        #creating frame for progress bar
        
        self.barFrame = Frame(self.backFrame,bg="White",height=200,width=400)
        self.barFrame.place(x=120,y=200)
        self.barFrame1 = Frame(self.backFrame,bg="White",height=200,width=400)
        self.barFrame1.place(x=120,y=400)
        
        barImg = Image.open("images/bars.png")
        # barImg = barImg.resize((6,200))
        barImg = ImageTk.PhotoImage(barImg)
        
        barUpper1 = ttk.Label(self.barFrame,image=barImg)
        barUpper1.place(x=40,y=0)
        barLower1 = ttk.Label(self.barFrame1,image=barImg)
        barLower1.place(x=40,y=0)
        
        def movingUpAndDownFrame1(bars,xcorr,ycorr):
            while True:
                #move bars in upward direction from mid to top
                if ycorr==0 and xcorr==40:
                    time.sleep(5) 
                    while ycorr!=-200:
                        bars.place(x=xcorr,y=ycorr)
                        ycorr-=1
                        time.sleep(.01)
               
                    
                if ycorr==-200 and xcorr==40:
                    while ycorr !=0:
                        bars.place(x=xcorr,y=ycorr)
                        ycorr+=1
                        time.sleep(.01)
               
        def movingUpAndDownFrame2(bars,xcorr,ycorr):
            while True:
                if ycorr==200 and xcorr==40:
                    while ycorr !=0:
                        bars.place(x=xcorr,y=ycorr)
                        ycorr-=1
                        time.sleep(.01)
                        
                #move bars in downward direction from mid to bottom       
                if ycorr==0 and xcorr==40:
                    time.sleep(5)
                    while ycorr!=200:
                        bars.place(x=xcorr,y=ycorr)
                        ycorr+=1
                        time.sleep(.01)

                
        #horizontal bars
        singleBarImg = Image.open("images/hb.png")
        # singleBarImg.resize((210,15))
        # singleBarImg = singleBarImg.rotate(90)  
        singleBarImg = ImageTk.PhotoImage(singleBarImg)
        
       
        leftbar1 = ttk.Label(self.barFrame1,image=singleBarImg)
        leftbar1.place(x=0,y=0)
        
      
        rightbar1 = ttk.Label(self.barFrame1,image=singleBarImg)
        rightbar1.place(y=0,x=202)
        def movingleftAndright(bars,xcorr,ycorr):
            while True:
                if ycorr==0 and xcorr==0:
                    time.sleep(5)
                    while xcorr !=-200:
                        bars.place(x=xcorr,y=ycorr)
                        xcorr-=1
                        time.sleep(.01)
                        
                #move bars in downward direction from mid to bottom       
                if ycorr==0 and xcorr==-200:
                    # time.sleep(15)
                    while xcorr!=0:
                        bars.place(x=xcorr,y=ycorr)
                        xcorr+=1
                        time.sleep(.01)
                    
        def movingleftAndright2(bars,xcorr,ycorr):
            while True:
                if ycorr==0 and xcorr==210:
                    time.sleep(5)
                    while xcorr !=410:
                        bars.place(x=xcorr,y=ycorr)
                        xcorr+=1
                        time.sleep(.01)
                        
                #move bars in downward direction from mid to bottom       
                if ycorr==0 and xcorr==410:
                    # time.sleep(15)
                    while xcorr!=210:
                        bars.place(x=xcorr,y=ycorr)
                        xcorr-=1
                        time.sleep(.01)

                      
        threading.Thread(target=movingUpAndDownFrame1 , args=(barUpper1,40,-200)).start() 
        threading.Thread(target=movingUpAndDownFrame2, args=(barLower1,40,200)).start()
        threading.Thread(target=movingleftAndright,args=(leftbar1,-200,0)).start()   
        threading.Thread(target=movingleftAndright2, args=(rightbar1,410,0)).start()    
        self.userInteractPanel = Frame(self.backFrame,height=350,width=400,bg="#ffffff")
        self.userInteractPanel.place(x=650,y=200)
        
        #configuring user label pattern
        configLabel = ttk.Style()
        configLabel.configure("Custom.TLabel",foreground="#325461",font=("MuseoModerno",15),background="#ffffff")
        self.userLabel = ttk.Label(self.userInteractPanel,text="Username",style="Custom.TLabel")
        self.userLabel.place(x=50,y=50)
        self.PassLabel = ttk.Label(self.userInteractPanel,text="Password",style="Custom.TLabel")
        self.PassLabel.place(x=50,y=150)
        
        #confiuring user Entry field
        self.userEntry = ttk.Entry(self.userInteractPanel,width=30,font=("Consolas",15))
        self.userEntry.place(x=30,y=100)
        
        self.passEntry = ttk.Entry(self.userInteractPanel,width=30,font=("Consolas",15),show="*")
        self.passEntry.place(x=30,y=200)
        
        def login():
            if self.userEntry.get()and self.passEntry.get():
                data = (self.userEntry.get(),self.passEntry.get())
                res = Database.loginFunction(data)
                if res:
                    messagebox.showinfo("Success","Login Successfull")
                    self.window.destroy()
                    Dashboard.dashboard(data)
            else:
                messagebox.showerror("Alert","Username or password is invalid")
                
        #configuring button
        self.submitButton = ttk.Button(self.userInteractPanel,text="Sign In",command=login)
        self.submitButton.place(x=150,y=250)
        

        self.window.mainloop()
        
if __name__=="__main__":        
    login()
