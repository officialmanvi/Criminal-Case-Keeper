from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from ttkthemes import ThemedTk
from datetime import datetime
from PIL import Image,ImageTk
import Database,Dashboard,Selection
class visitor :
    def __init__(self,coll,data):
        
        self.coll = coll
        
        
        def refresh():
            self.dateEntry.delete(0,END)
            now = datetime.now()
            dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
            self.dateEntry.insert(END,dt_string)
           

        #defining window
        self.window =ThemedTk()

        #getting Display Co-ordinates
        self.xcorr = self.window.winfo_screenwidth()
        self.ycorr = self.window.winfo_screenheight()

        #declaring width and height of window
        self.width = 1200
        self.height = 700

        #getting margins of window in order to place window in the mid of display
        self.xcorr = int((self.xcorr)/2 - (self.width)/2)
        self.ycorr = int((self.ycorr)/2 - (self.height)/2)

        #setting margins and dimensions of window
        self.window.geometry(f"{self.width}x{self.height}+{self.xcorr}+{int(self.ycorr/1.5)}")

        #setting title of Login page
        self.window.title("Add Client")

        #applying style:
        style = ttk.Style(self.window)
        style.theme_use('plastik')

        #placing frame
        self.backFrame = Frame(self.window,bg="#ffffff",height=self.height,width=self.width)
        self.backFrame.place(x=0,y=0)

        #placing title Label
        configLabel = ttk.Style()
        configLabel.configure("TLabel",background="#ffffff",foreground="#932df8",font=("museoModerno",25))
        self.titleName = Label(self.backFrame,text="Add",bg="#ffffff",font=("museoModerno",25))
        self.titleName.place(x=50,y=37)
        self.titleName1 = ttk.Label(self.backFrame,text="Visitor",style="TLabel")
        self.titleName1.place(x=125,y=37)

        # placing Image Frame
        self.imgFrame = Frame(self.backFrame,width=550,height=500,bg="#ffffff")
        self.imgFrame.place(x=50,y=125)

        visitorimg = Image.open("images/pics.png")
        visitorimg = visitorimg.resize((450,450))
        visitorimg = ImageTk.PhotoImage(visitorimg)
        Label(self.imgFrame,image=visitorimg,bg="#ffffff").place(x=0,y=0)

        #creating frame for deploying widgets
        self.widgetFrame = Frame(self.backFrame,width=550,height=500,bg="#ffffff")
        self.widgetFrame.place(x=550,y=125)


        #styling ttk label
        ttk.Style().configure("Custom.TLabel",font=("museoModerno",13),foreground="#000000")
        #visitor Name
        self.visitorName = ttk.Label(self.widgetFrame,text="Visitor's Name",style="Custom.TLabel")
        self.visitorName.place(x=50,y=50)

        #visitor ID
        self.visitorId = ttk.Label(self.widgetFrame,text="Visitor's Id",style="Custom.TLabel")
        self.visitorId.place(x=50,y=100)

        #visitor ID number
        self.idNum = ttk.Label(self.widgetFrame,text="Id Number",style="Custom.TLabel")
        self.idNum.place(x=50,y=150)

        #criminal criminal id
        self.criminalId = ttk.Label(self.widgetFrame,text="Criminal ID",style="Custom.TLabel")
        self.criminalId.place(x=50,y=200)

        #visitor date
        self.date = ttk.Label(self.widgetFrame,text="Date",style="Custom.TLabel")
        self.date.place(x=50,y=250)

        #visitor relation
        self.relation = ttk.Label(self.widgetFrame,text="Visitor's Relation",style="Custom.TLabel")
        self.relation.place(x=50,y=300)

        #visitor relation
        self.contact = ttk.Label(self.widgetFrame,text="Contact No.",style="Custom.TLabel")
        self.contact.place(x=50,y=350)

        #entry Fields
        self.vNameEntry = ttk.Entry(self.widgetFrame,width=35,font=("Libre Baskerville",11))
        self.vNameEntry.place(x=200,y=50)

        self.visitorIdEntry = ttk.Entry(self.widgetFrame,width=35,font=("Libre Baskrville",11))
        self.visitorIdEntry.place(x=200,y=100)

        self.idNumEntry = ttk.Entry(self.widgetFrame,width=35,font=("Libre Baskrville",11))
        self.idNumEntry.place(x=200,y=150)

        self.criminalIdEntry = ttk.Entry(self.widgetFrame,width=35,font=("Libre Baskrville",11))
        self.criminalIdEntry.place(x=200,y=200)
        
        self.criminalIdEntry.insert(END,self.coll)

        self.dateEntry = ttk.Entry(self.widgetFrame,width=35,font=("Libre Baskrville",11),state=READABLE)
        self.dateEntry.place(x=200,y=250)
        
        # placing a refresh button
        refreshImg = Image.open('images/refreshing.png')
        refreshImg = ImageTk.PhotoImage(refreshImg)
        self.refresh=Button(self.widgetFrame,image=refreshImg,relief=FLAT, command=refresh, bg="#ffffff")
        self.refresh.place(x=500,y=250)

        self.relationEntry = ttk.Entry(self.widgetFrame,width=35,font=("Libre Baskrville",11))
        self.relationEntry.place(x=200,y=300)

        self.contactEntry = ttk.Entry(self.widgetFrame,width=35,font=("Libre Baskrville",11))
        self.contactEntry.place(x=200,y=350)
        
        def submit():
            if self.vNameEntry.get().strip() and self.visitorIdEntry.get().strip():
                if self.idNumEntry.get().strip() and self.criminalIdEntry.get().strip():
                    if self.dateEntry.get().strip() and self.contactEntry.get().strip():
                        if self.relationEntry.get().strip():
                            data = (self.vNameEntry.get().strip(),self.visitorIdEntry.get().strip(),self.idNumEntry.get().strip(),self.criminalIdEntry.get().strip(),self.dateEntry.get().strip(),self.relationEntry.get().strip(),self.contactEntry.get().strip())
                            print(data)
                            res = Database.addVisitor(data)
                            if res:
                                messagebox.showinfo("Sucess","Visitor added succesfully")
                            else:
                                messagebox.showerror("Alert","An error has been generated")
                        else:
                            messagebox.showerror("Alert","Please specify relation of visitor with criminal")
                    else:
                        messagebox.showerror("Alert","Date or Contact number is missing")
                else:
                    messagebox.showerror("Alert","Visitor id number or Criminal id number is missing")
            else:
                messagebox.showerror("Alert","Visitor name or id is missing")
                
        #btns
        img = Image.open('images/btn.png')
        img =ImageTk.PhotoImage(img)
        Button(self.widgetFrame,image=img,relief=FLAT,command=submit).place(x=215,y=400)

        refresh()

        #binding close 
        def onClosing():
            self.window.destroy()
            Selection.Selection(1,data)
           
        self.window.protocol("WM_DELETE_WINDOW",onClosing)
        self.window.mainloop()

if __name__=='__main__':
    visitor()