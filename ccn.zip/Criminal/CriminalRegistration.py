from tkinter import *
from tkinter import ttk
from ttkthemes import ThemedTk
from PIL import Image,ImageTk 
from tkinter import messagebox,filedialog
import Database,base64,Dashboard


class Register:
    def __init__(self,data):
        
        self.convertedString=''
        self.data=[]
         #defining window
        self.window =ThemedTk()

        #getting Display Co-ordinates
        self.xcorr = self.window.winfo_screenwidth()
        self.ycorr = self.window.winfo_screenheight()

        #declaring width and height of window
        self.width = 1200   
        self.height = 750

        #getting margins of window in order to place window in the mid of display
        self.xcorr = int((self.xcorr)/2 - (self.width)/2)
        self.ycorr = int((self.ycorr)/2 - (self.height)/2)

        #setting margins and dimensions of window
        self.window.geometry(f"{self.width}x{self.height}+{self.xcorr}+{int(self.ycorr/1.5)}")
        self.window.resizable(False,False)
        
         #setting title of Login page
        self.window.title("REGISTER CRIMINAL")

        #applying style:
        style = ttk.Style(self.window)
        style.theme_use('plastik')
        
         #placing frame
        self.backFrame = Frame(self.window,bg="#ffffff",height=self.height,width=self.width)
        self.backFrame.place(x=0,y=0)

        #placing title Label
        configLabel = ttk.Style()
        configLabel.configure("TLabel",background="#ffffff",foreground="#932df8",font=("museoModerno",25))
        self.titleName = Label(self.backFrame,text="Enroll",bg="#ffffff",font=("museoModerno",25))
        self.titleName.place(x=50,y=25)
        self.titleName1 = ttk.Label(self.backFrame,text="Criminal",style="TLabel")
        self.titleName1.place(x=150,y=25)
        

        #self.widgetframe
        self.widgetFrame = Frame(self.backFrame,background="#ffffff",width=500,height=500)
        self.widgetFrame.place(x=600,y=150)
        
        self.widgetFrame2 = Frame(self.backFrame,background="#ffffff",width=500,height=500)
        # Placing Label
        ttk.Style().configure("Custom.TLabel",font=("Libre Baskerville",11),foreground="Black")
        self.casenumber = ttk.Label(self.widgetFrame,text="Criminal' Name",style="Custom.TLabel")
        self.casenumber.place(x=50,y=10) 
        
        self.Address = ttk.Label(self.widgetFrame,text="Address",style="Custom.TLabel")
        self.Address.place(x=50,y=60)
        
        self.gender = ttk.Label(self.widgetFrame,text="Gender",style="Custom.TLabel")
        self.gender.place(x=50,y=110)
        
        self.DOB = ttk.Label(self.widgetFrame,text="D.O.B ",style="Custom.TLabel")
        self.DOB.place(x=50,y=160)

        self.idType = ttk.Label(self.widgetFrame,text="Id's Type ",style="Custom.TLabel")
        self.idType.place(x=50,y=210)

        self.Idnum = ttk.Label(self.widgetFrame,text="Id Number",style="Custom.TLabel")
        self.Idnum.place(x=50,y=260)

        self.type = ttk.Label(self.widgetFrame2,text="Offence's Type",style="Custom.TLabel")
        self.type.place(x=50,y=10)
        
        self.Dateofincident = ttk.Label(self.widgetFrame2,text="Date of Incident",style="Custom.TLabel")
        self.Dateofincident.place(x=50,y=60)
        
        
        
        #Placing entry wizard
        self.caseAddress = ttk.Entry(self.widgetFrame,width=30,font=("Consolas",12))
        self.caseAddress.place(x=205,y=60)
        
        self.criminalEntry = ttk.Entry(self.widgetFrame,width=30,font=("Consolas",12))
        self.criminalEntry.place(x=205,y=10)
        
        self.criminalGender = ttk.Combobox(self.widgetFrame,width=28,values=("Male","Female","Others"),font=("Consolas",12),state="readonly")
        self.criminalGender.place(x=205,y=110)
        
        self.DOBEntry = ttk.Entry(self.widgetFrame,width=30,font=("Consolas",12))
        self.DOBEntry.place(x=205,y=160)

        self.IDTypeEntry = ttk.Combobox(self.widgetFrame,width=28,font=("Consolas",12),values=("Aadhar","Pan Card","Voter ID Card","Passport","Birth Certificate"))
        self.IDTypeEntry.place(x=205,y=210)

        self.IDEntry = ttk.Entry(self.widgetFrame,width=30,font=("Consolas",12))
        self.IDEntry.place(x=205,y=260)

        self.offenceTypeEntry = ttk.Combobox(self.widgetFrame2,width=28,values=("Civilian","Criminal"),font=("Consolas",12))
        self.offenceTypeEntry.place(x=205,y=10)
        
        self.dateEntry = ttk.Entry(self.widgetFrame2,width=30,font=("Consolas",12))
        self.dateEntry.place(x=205,y=60)
        
        
        
        # Placing Image
        self.img=Image.open('images/Reg pic.png')
        self.img=self.img.resize((500,550))

        self.imgTk = ImageTk.PhotoImage(self.img)
        self.imglbl=Label(self.backFrame,image=self.imgTk,bg = "#ffffff")
        self.imglbl.place(x=50,y=80)
        
        
        self.Sentence = ttk.Label(self.widgetFrame2,text="Jail Term",style="Custom.TLabel")
        self.Sentence.place(x=50,y=110)

        self.CriminalSummary = ttk.Label(self.widgetFrame2,text="Crime Summary",style="Custom.TLabel")
        self.CriminalSummary.place(x=50,y=160)        

        self.SentenceEntry=ttk.Entry(self.widgetFrame2,width=30,font=("Consolas",12))
        self.SentenceEntry.place(x=205,y=110)

        self.crimeSummaryEntry=Text(self.widgetFrame2,width=35,height=3,borderwidth=3,relief=RIDGE)
        self.crimeSummaryEntry.place(x=205,y=160)
        
        upIMG = Image.open("images/upload.png")
        upIMG = upIMG.resize((280,30)) 
        upIMG = ImageTk.PhotoImage(upIMG)
        
        self.imgLabel = ttk.Label(self.widgetFrame,text="Upload pic",style="Custom.TLabel").place(x=50,y=310)
        self.imgButonEntry = Button(self.widgetFrame,image=upIMG,relief=FLAT,command=self.upload).place(x=205,y=310)

                #configuring button
        self.imgBtn= Image.open('images/nextBTN.png')
        self.imgBtn=ImageTk.PhotoImage(self.imgBtn)
        self.nextButton = Button(self.widgetFrame,image=self.imgBtn,relief=FLAT,command=self.next)
        self.nextButton.place(x=205,y=360)
        
        self.imgBtn1= Image.open('images/submitBtn.png')
        self.imgBtn1=ImageTk.PhotoImage(self.imgBtn1)
        self.submitButton = Button(self.widgetFrame2,image=self.imgBtn1,relief=FLAT,command=self.action)
        self.submitButton.place(x=305,y=360)
        
        self.imgBtn2= Image.open('images/previous.png')
        self.imgBtn2=ImageTk.PhotoImage(self.imgBtn2)
        self.prevButton = Button(self.widgetFrame2,image=self.imgBtn2,relief=FLAT,command=self.previous)
        self.prevButton.place(x=105,y=360)
        
        def onClosing():
            self.window.destroy()
            Dashboard.dashboard(data)
        self.window.protocol("WM_DELETE_WINDOW",onClosing)
        

        
        self.window.mainloop()
    def previous(self):
        self.widgetFrame2.place_forget()
    def upload(self):
        fd = filedialog.askopenfile()
        print(str(fd))
        String=str(fd).split(" ")
        String = String[1].split("=")
        print(String)
        fd= String[1].strip("''")
        print(fd)
        with open(fd, "rb") as image2string:
            converted_string = base64.b64encode(image2string.read())
            print(converted_string)
        with open('encode.bin', "wb") as file:
            file.write(converted_string)
        self.convertedString = converted_string
        
            
        # pass
    def next(self):
        if self.criminalEntry.get() and self.caseAddress.get() and self.DOBEntry.get():
            if self.IDEntry.get() and self.criminalGender.get() and self.IDTypeEntry.get():
                count1=Database.getcount()
                getcount=f"CCK{count1[0]+1}"
                self.data=[getcount,self.criminalEntry.get(),self.caseAddress.get(),self.criminalGender.get(),self.DOBEntry.get(),self.IDTypeEntry.get(),self.IDEntry.get(),self.convertedString]
                self.widgetFrame2.place(x=600,y=150)
            else:
                messagebox.showerror("Alert","Gender or idtype or id number is necessary")
        else:
            messagebox.showerror("Alert","criminal name or address or DOB is necessary")    
    
    def action(self):   
        if self.offenceTypeEntry.get() and self.dateEntry.get() and self.SentenceEntry.get():                
            self.data.append(self.offenceTypeEntry.get())
            self.data.append(self.dateEntry.get())
            self.data.append(self.SentenceEntry.get())
            self.data.append(self.crimeSummaryEntry.get("1.0","end-1c"))
                    
            if Database.insertCriminal(self.data):
                messagebox.showinfo("Sucess","Criminal registered successfully")
            else:
                messagebox.showerror("Alert","An error occured") 
                print(self.data)

        else:
            messagebox.showerror("Alert","Specify the date or type of offence" )
                   

        
if __name__ == "__main__":
    Register(('himanshu',))